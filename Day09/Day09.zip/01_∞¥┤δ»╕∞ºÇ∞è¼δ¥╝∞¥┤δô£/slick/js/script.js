// 문서 준비 이벤트
$(function() {

    // 슬릭 슬라이드 시작!
    $('.slide-container').slick()

})